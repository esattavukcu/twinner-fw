ML16 Coding Module firmware
Basic operations:
Check the BLE connection, reads the BLE messages, apply the commands, write the response back.
